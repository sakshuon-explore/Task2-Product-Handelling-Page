const product = [
  { id: 0, image: 'image/1.jpg', title: 'Z Flip Foldable Mobile', price: 10020 },
  { id: 1, image: 'image/2.jpg', title: 'Air Pods Pro', price: 1260 },
  { id: 2, image: 'image/3.jpg', title: '250D DSLR Camera', price: 20030 },
  { id: 3, image: 'image/4.jpg', title: 'Head Phones', price: 1000 },
  { id: 4, image: 'image/5.jpg', title: 'Bluetooth', price: 500 },
  { id: 5, image: 'image/6.jpg', title: 'Smart Watch', price: 75000 },
  { id: 6, image: 'image/7.jpg', title: 'Pendrive', price: 750 },
  { id: 8, image: 'image/8.jpg', title: 'Radio', price: 1020 },
  { id: 9, image: 'image/9.jpg', title: 'Alaska', price: 1100 },
  { id: 10, image: 'image/10.jpg', title: 'Charger', price: 1100 }
];

const categories = [...new Set(product)];

document.getElementById('root').innerHTML = categories.map((item) => {
  var { id, image, title, price } = item;
  return (
    `<div class='box'>
      <div class='img-box'>
        <img class='images' src=${image}></img>
      </div>
      <div class='bottom'>
        <p>${title}</p>
        <h2>$ ${price}.00</h2>
        <button onclick='addtocart(${id})'>Add to cart</button>
      </div>
    </div>`
  );
}).join('');

var cart = [];

function addtocart(a) {
  let selectedItem = categories.find(item => item.id === a);
  let existingItem = cart.find(item => item.id === a);

  if (existingItem) {
    existingItem.quantity++; // Increase quantity if already in cart
  } else {
    cart.push({ ...selectedItem, quantity: 1 }); // Add with quantity = 1
  }

  displaycart();
}

function delElement(a) {
  let itemIndex = cart.findIndex(item => item.id === a);

  if (itemIndex !== -1) {
    if (cart[itemIndex].quantity > 1) {
      cart[itemIndex].quantity--; // Decrease quantity if more than 1
    } else {
      cart.splice(itemIndex, 1); // Remove item if quantity is 1
    }
  }

  displaycart();
}

// Function to completely remove an item from the cart
function removeItem(id) {
  cart = cart.filter(item => item.id !== id);
  displaycart();
}

function displaycart() {
  let total = 0;
  document.getElementById("count").innerHTML = cart.length;

  if (cart.length == 0) {
    document.getElementById('cartItem').innerHTML = "Your cart is empty";
    document.getElementById("total").innerHTML = "$ 0.00";
  } else {
    document.getElementById("cartItem").innerHTML = cart.map((items) => {
      var { id, image, title, price, quantity } = items;
      total += price * quantity;
      return (
        `<div class='cart-item'>
          <div class='row-img'>
            <img class='rowimg' src=${image}>
          </div>
          <p style='font-size:12px;'>${title}</p>
          <h2 style='font-size: 15px;'>$ ${price * quantity}.00</h2>
          <button onclick='addtocart(${id})'>+</button>
          <span>${quantity}</span>
          <button onclick='delElement(${id})'>-</button>
          <i class='fa-solid fa-trash' onclick='removeItem(${id})'></i>
        </div>`
      );
    }).join('');

    document.getElementById("total").innerHTML = "$ " + total + ".00";
  }
}
